import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, BarChart3 } from 'lucide-react';
import { Stock } from '../types';

interface MetricsProps {
  stocks: Stock[];
}

export function DashboardMetrics({ stocks }: MetricsProps) {
  const totalInvestment = stocks.reduce((sum, stock) => sum + stock.buyPrice, 0);
  const currentValue = stocks.reduce((sum, stock) => sum + stock.currentPrice, 0);
  const profitLoss = currentValue - totalInvestment;
  const profitLossPercentage = (profitLoss / totalInvestment) * 100;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Total Investment</p>
            <p className="text-2xl font-bold">${totalInvestment.toFixed(2)}</p>
          </div>
          <DollarSign className="h-8 w-8 text-blue-500" />
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Current Value</p>
            <p className="text-2xl font-bold">${currentValue.toFixed(2)}</p>
          </div>
          <BarChart3 className="h-8 w-8 text-green-500" />
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Profit/Loss</p>
            <p className={`text-2xl font-bold ${profitLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              ${profitLoss.toFixed(2)}
            </p>
          </div>
          {profitLoss >= 0 ? (
            <TrendingUp className="h-8 w-8 text-green-500" />
          ) : (
            <TrendingDown className="h-8 w-8 text-red-500" />
          )}
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Return</p>
            <p className={`text-2xl font-bold ${profitLossPercentage >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {profitLossPercentage.toFixed(2)}%
            </p>
          </div>
          <BarChart3 className="h-8 w-8 text-purple-500" />
        </div>
      </div>
    </div>
  );
}