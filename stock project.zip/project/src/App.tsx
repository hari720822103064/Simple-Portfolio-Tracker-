import React, { useState, useEffect } from 'react';
import { Stock, StockFormData } from './types';
import { DashboardMetrics } from './components/DashboardMetrics';
import { StockForm } from './components/StockForm';
import { StockTable } from './components/StockTable';

// Mock data for demonstration
const mockStocks: Stock[] = [
  {
    id: '1',
    name: 'Apple Inc.',
    ticker: 'AAPL',
    quantity: 1,
    buyPrice: 150.00,
    currentPrice: 175.50,
  },
  {
    id: '2',
    name: 'Microsoft Corporation',
    ticker: 'MSFT',
    quantity: 1,
    buyPrice: 280.00,
    currentPrice: 310.25,
  },
  {
    id: '3',
    name: 'Amazon.com Inc.',
    ticker: 'AMZN',
    quantity: 1,
    buyPrice: 130.00,
    currentPrice: 145.75,
  },
  {
    id: '4',
    name: 'Alphabet Inc.',
    ticker: 'GOOGL',
    quantity: 1,
    buyPrice: 120.00,
    currentPrice: 135.50,
  },
  {
    id: '5',
    name: 'Tesla Inc.',
    ticker: 'TSLA',
    quantity: 1,
    buyPrice: 240.00,
    currentPrice: 225.75,
  },
];

function App() {
  const [stocks, setStocks] = useState<Stock[]>(mockStocks);
  const [editingStock, setEditingStock] = useState<Stock | null>(null);
  const [showForm, setShowForm] = useState(false);

  const handleAddStock = (data: StockFormData) => {
    const newStock: Stock = {
      id: Date.now().toString(),
      ...data,
      currentPrice: data.buyPrice, // In a real app, this would come from an API
    };
    setStocks([...stocks, newStock]);
    setShowForm(false);
  };

  const handleEditStock = (data: StockFormData) => {
    if (!editingStock) return;
    
    const updatedStocks = stocks.map((stock) =>
      stock.id === editingStock.id
        ? { ...stock, ...data }
        : stock
    );
    setStocks(updatedStocks);
    setEditingStock(null);
    setShowForm(false);
  };

  const handleDeleteStock = (id: string) => {
    setStocks(stocks.filter((stock) => stock.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Stock Portfolio Dashboard</h1>
          {!showForm && (
            <button
              onClick={() => setShowForm(true)}
              className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Add New Stock
            </button>
          )}
        </div>

        <DashboardMetrics stocks={stocks} />

        {showForm && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">
              {editingStock ? 'Edit Stock' : 'Add New Stock'}
            </h2>
            <StockForm
              onSubmit={editingStock ? handleEditStock : handleAddStock}
              initialData={editingStock || undefined}
            />
          </div>
        )}

        <div>
          <h2 className="text-xl font-semibold mb-4">Current Holdings</h2>
          <StockTable
            stocks={stocks}
            onEdit={(stock) => {
              setEditingStock(stock);
              setShowForm(true);
            }}
            onDelete={handleDeleteStock}
          />
        </div>
      </div>
    </div>
  );
}

export default App;